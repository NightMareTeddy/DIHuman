# Backend - FastAPI and Firebase setup
